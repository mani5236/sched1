/********************************************************************
 * HFSC Scheduler - Unit Tests
 * 
 * Comprehensive test suite for verifying HFSC correctness
 ********************************************************************/

#include "hfsc_scheduler.h"
#include <rte_eal.h>
#include <rte_mbuf.h>
#include <rte_mempool.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

/* Test utilities */
#define TEST_ASSERT(cond, msg) \
    do { \
        if (!(cond)) { \
            printf("FAIL: %s:%d: %s\n", __FILE__, __LINE__, msg); \
            return -1; \
        } \
    } while (0)

#define TEST_PASS() \
    do { \
        printf("PASS: %s\n", __func__); \
        return 0; \
    } while (0)

static struct rte_mempool *pktmbuf_pool = NULL;

/* Create a test packet */
static struct rte_mbuf *
create_test_packet(uint32_t len)
{
    struct rte_mbuf *m;
    
    m = rte_pktmbuf_alloc(pktmbuf_pool);
    if (m == NULL)
        return NULL;
    
    m->pkt_len = len;
    m->data_len = len;
    
    return m;
}

/* Test 1: Basic scheduler initialization */
static int
test_init(void)
{
    hfsc_scheduler_t *sched = NULL;
    
    TEST_ASSERT(hfsc_init(&sched) == 0, "Scheduler init failed");
    TEST_ASSERT(sched != NULL, "Scheduler is NULL");
    TEST_ASSERT(sched->root == NULL, "Root should be NULL initially");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 2: Root class creation */
static int
test_root_creation(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root;
    hfsc_service_curve_t sc = {
        .m1 = 12500000,  /* 100 Mbps */
        .d = 0,
        .m2 = 12500000
    };
    
    hfsc_init(&sched);
    
    root = hfsc_create_root(sched, &sc, &sc, &sc);
    TEST_ASSERT(root != NULL, "Root creation failed");
    TEST_ASSERT(sched->root == root, "Root not set in scheduler");
    TEST_ASSERT(root->parent == NULL, "Root should have no parent");
    TEST_ASSERT(!root->is_leaf, "Root should not be leaf");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 3: Leaf class creation and hierarchy */
static int
test_hierarchy_creation(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *parent, *leaf1, *leaf2;
    hfsc_service_curve_t sc = {
        .m1 = 12500000,
        .d = 0,
        .m2 = 12500000
    };
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &sc, &sc, &sc);
    
    /* Create interior class */
    sc.m1 = 6250000;  /* 50 Mbps */
    sc.m2 = 6250000;
    parent = hfsc_create_class(sched, root, 1, false, &sc, &sc, NULL);
    TEST_ASSERT(parent != NULL, "Parent creation failed");
    TEST_ASSERT(parent->parent == root, "Parent link incorrect");
    TEST_ASSERT(root->num_children == 1, "Root should have 1 child");
    
    /* Create leaf classes */
    sc.m1 = 3125000;  /* 25 Mbps */
    sc.m2 = 3125000;
    leaf1 = hfsc_create_class(sched, parent, 11, true, &sc, &sc, NULL);
    leaf2 = hfsc_create_class(sched, parent, 12, true, &sc, &sc, NULL);
    
    TEST_ASSERT(leaf1 != NULL && leaf2 != NULL, "Leaf creation failed");
    TEST_ASSERT(leaf1->is_leaf && leaf2->is_leaf, "Leaves should be marked as leaf");
    TEST_ASSERT(parent->num_children == 2, "Parent should have 2 children");
    TEST_ASSERT(leaf1->queue != NULL, "Leaf should have queue");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 4: Service curve initialization */
static int
test_service_curves(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl;
    hfsc_service_curve_t rsc, fsc, usc;
    
    hfsc_init(&sched);
    
    /* Root with linear curve */
    rsc = (hfsc_service_curve_t){12500000, 0, 12500000};
    fsc = rsc;
    usc = rsc;
    root = hfsc_create_root(sched, &rsc, &fsc, &usc);
    
    /* Leaf with two-piece curve (concave for RT) */
    rsc = (hfsc_service_curve_t){
        .m1 = 5000000,   /* 40 Mbps initial */
        .d = 10000,      /* 10ms */
        .m2 = 1250000    /* 10 Mbps sustained */
    };
    fsc = (hfsc_service_curve_t){1250000, 0, 1250000};
    usc = (hfsc_service_curve_t){2000000, 0, 2000000};
    
    cl = hfsc_create_class(sched, root, 1, true, &rsc, &fsc, &usc);
    TEST_ASSERT(cl != NULL, "Class creation with curves failed");
    
    /* Verify curves stored correctly */
    TEST_ASSERT(cl->rsc.m1 == 5000000, "RSC m1 incorrect");
    TEST_ASSERT(cl->rsc.d == 10000, "RSC d incorrect");
    TEST_ASSERT(cl->rsc.m2 == 1250000, "RSC m2 incorrect");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 5: Enqueue and activation */
static int
test_enqueue_activation(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl;
    struct rte_mbuf *m;
    hfsc_service_curve_t sc = {1250000, 0, 1250000};
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &sc, &sc, &sc);
    cl = hfsc_create_class(sched, root, 1, true, &sc, &sc, NULL);
    
    /* Initially inactive */
    TEST_ASSERT(cl->state == HFSC_CLASS_INACTIVE, "Class should be inactive");
    TEST_ASSERT(root->state == HFSC_CLASS_INACTIVE, "Root should be inactive");
    
    /* Enqueue packet */
    m = create_test_packet(1500);
    TEST_ASSERT(m != NULL, "Packet creation failed");
    TEST_ASSERT(hfsc_enqueue(sched, cl, m) == 0, "Enqueue failed");
    
    /* Should be activated */
    TEST_ASSERT(cl->state == HFSC_CLASS_ACTIVE, "Class should be active");
    TEST_ASSERT(root->state == HFSC_CLASS_ACTIVE, "Root should be active");
    TEST_ASSERT(cl->qlen == 1, "Queue length should be 1");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 6: Dequeue and deactivation */
static int
test_dequeue_deactivation(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl;
    struct rte_mbuf *m, *deq;
    hfsc_service_curve_t sc = {1250000, 0, 1250000};
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &sc, &sc, &sc);
    cl = hfsc_create_class(sched, root, 1, true, &sc, &sc, NULL);
    
    /* Enqueue and dequeue */
    m = create_test_packet(1500);
    hfsc_enqueue(sched, cl, m);
    
    deq = hfsc_dequeue(sched);
    TEST_ASSERT(deq == m, "Dequeued wrong packet");
    TEST_ASSERT(cl->qlen == 0, "Queue should be empty");
    TEST_ASSERT(cl->state == HFSC_CLASS_INACTIVE, "Class should be inactive");
    
    rte_pktmbuf_free(deq);
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 7: Service accounting */
static int
test_service_accounting(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl;
    struct rte_mbuf *m1, *m2;
    hfsc_service_curve_t rsc = {1250000, 0, 1250000};
    hfsc_service_curve_t fsc = {1250000, 0, 1250000};
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &rsc, &fsc, NULL);
    cl = hfsc_create_class(sched, root, 1, true, &rsc, &fsc, NULL);
    
    /* Enqueue two packets */
    m1 = create_test_packet(1000);
    m2 = create_test_packet(1500);
    hfsc_enqueue(sched, cl, m1);
    hfsc_enqueue(sched, cl, m2);
    
    uint64_t initial_total = cl->total;
    uint64_t initial_cumul = cl->cumul;
    
    /* Dequeue first packet */
    struct rte_mbuf *deq = hfsc_dequeue(sched);
    TEST_ASSERT(deq != NULL, "Dequeue failed");
    TEST_ASSERT(cl->total == initial_total + 1000, "Total service incorrect");
    TEST_ASSERT(cl->cumul >= initial_cumul, "Cumul service should increase");
    
    rte_pktmbuf_free(deq);
    
    /* Dequeue second packet */
    deq = hfsc_dequeue(sched);
    TEST_ASSERT(deq != NULL, "Second dequeue failed");
    TEST_ASSERT(cl->total == initial_total + 2500, "Total service incorrect");
    
    rte_pktmbuf_free(deq);
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 8: RT criterion selection */
static int
test_rt_selection(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *rt_cl, *be_cl;
    struct rte_mbuf *m1, *m2, *deq;
    hfsc_service_curve_t rsc_rt = {5000000, 10000, 1250000};  /* RT curve */
    hfsc_service_curve_t fsc = {1250000, 0, 1250000};
    hfsc_service_curve_t rsc_be = {1250000, 0, 1250000};      /* No RT */
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &fsc, &fsc, NULL);
    
    /* RT class with delay guarantee */
    rt_cl = hfsc_create_class(sched, root, 1, true, &rsc_rt, &fsc, NULL);
    
    /* Best-effort class */
    be_cl = hfsc_create_class(sched, root, 2, true, &rsc_be, &fsc, NULL);
    
    /* Enqueue to both */
    m1 = create_test_packet(1000);
    m2 = create_test_packet(1000);
    hfsc_enqueue(sched, be_cl, m1);
    hfsc_enqueue(sched, rt_cl, m2);
    
    /* Should select RT class first (when eligible) */
    deq = hfsc_dequeue(sched);
    TEST_ASSERT(deq == m2, "Should select RT packet first");
    
    rte_pktmbuf_free(deq);
    
    deq = hfsc_dequeue(sched);
    TEST_ASSERT(deq == m1, "Should get BE packet next");
    
    rte_pktmbuf_free(deq);
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 9: Virtual time fairness */
static int
test_virtual_time(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl1, *cl2;
    hfsc_service_curve_t fsc1 = {1250000, 0, 1250000};  /* 10 Mbps */
    hfsc_service_curve_t fsc2 = {2500000, 0, 2500000};  /* 20 Mbps */
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &fsc1, &fsc1, NULL);
    
    cl1 = hfsc_create_class(sched, root, 1, true, NULL, &fsc1, NULL);
    cl2 = hfsc_create_class(sched, root, 2, true, NULL, &fsc2, NULL);
    
    /* Enqueue to both */
    for (int i = 0; i < 10; i++) {
        hfsc_enqueue(sched, cl1, create_test_packet(1000));
        hfsc_enqueue(sched, cl2, create_test_packet(1000));
    }
    
    /* Dequeue and verify virtual time progression */
    uint64_t vt1_initial = cl1->cl_vt;
    uint64_t vt2_initial = cl2->cl_vt;
    
    for (int i = 0; i < 20; i++) {
        struct rte_mbuf *m = hfsc_dequeue(sched);
        TEST_ASSERT(m != NULL, "Dequeue failed");
        rte_pktmbuf_free(m);
    }
    
    /* Virtual time should have advanced */
    TEST_ASSERT(cl1->cl_vt > vt1_initial || cl1->state == HFSC_CLASS_INACTIVE,
                "VT1 should advance");
    TEST_ASSERT(cl2->cl_vt > vt2_initial || cl2->state == HFSC_CLASS_INACTIVE,
                "VT2 should advance");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 10: USC enforcement */
static int
test_usc_enforcement(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl;
    struct rte_mbuf *m;
    hfsc_service_curve_t fsc = {10000000, 0, 10000000};  /* 80 Mbps */
    hfsc_service_curve_t usc = {1250000, 0, 1250000};    /* 10 Mbps limit */
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &fsc, &fsc, NULL);
    cl = hfsc_create_class(sched, root, 1, true, NULL, &fsc, &usc);
    
    /* Enqueue many packets */
    for (int i = 0; i < 100; i++) {
        m = create_test_packet(1500);
        if (hfsc_enqueue(sched, cl, m) < 0)
            rte_pktmbuf_free(m);
    }
    
    /* Dequeue rapidly - USC should throttle */
    uint64_t start = rte_get_tsc_cycles();
    int count = 0;
    
    while (hfsc_has_packets(sched) && count < 10) {
        m = hfsc_dequeue(sched);
        if (m) {
            count++;
            rte_pktmbuf_free(m);
        } else {
            break;  /* USC blocking */
        }
    }
    
    uint64_t elapsed = rte_get_tsc_cycles() - start;
    
    /* With USC, not all packets should be dequeueable immediately */
    TEST_ASSERT(count >= 0, "Should dequeue some packets");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 11: Queue overflow handling */
static int
test_queue_overflow(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl;
    struct rte_mbuf *m;
    hfsc_service_curve_t sc = {1250000, 0, 1250000};
    int enqueued = 0;
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &sc, &sc, NULL);
    cl = hfsc_create_class(sched, root, 1, true, &sc, &sc, NULL);
    
    /* Fill queue to capacity */
    for (int i = 0; i < HFSC_QUEUE_SIZE + 100; i++) {
        m = create_test_packet(1000);
        if (hfsc_enqueue(sched, cl, m) == 0) {
            enqueued++;
        } else {
            rte_pktmbuf_free(m);
        }
    }
    
    TEST_ASSERT(enqueued <= HFSC_QUEUE_SIZE, "Enqueued more than capacity");
    TEST_ASSERT(cl->stats_drops > 0, "Should have drops");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Test 12: Statistics accuracy */
static int
test_statistics(void)
{
    hfsc_scheduler_t *sched = NULL;
    hfsc_class_t *root, *cl;
    struct rte_mbuf *m;
    hfsc_service_curve_t sc = {1250000, 0, 1250000};
    uint64_t packets, bytes, drops;
    
    hfsc_init(&sched);
    root = hfsc_create_root(sched, &sc, &sc, NULL);
    cl = hfsc_create_class(sched, root, 1, true, &sc, &sc, NULL);
    
    /* Enqueue and dequeue packets */
    for (int i = 0; i < 10; i++) {
        m = create_test_packet(1000 + i * 100);
        hfsc_enqueue(sched, cl, m);
    }
    
    uint64_t expected_bytes = 0;
    for (int i = 0; i < 10; i++) {
        expected_bytes += 1000 + i * 100;
        m = hfsc_dequeue(sched);
        if (m)
            rte_pktmbuf_free(m);
    }
    
    hfsc_get_class_stats(cl, &packets, &bytes, &drops);
    
    TEST_ASSERT(packets == 10, "Packet count incorrect");
    TEST_ASSERT(bytes == expected_bytes, "Byte count incorrect");
    TEST_ASSERT(drops == 0, "Should have no drops");
    
    hfsc_cleanup(sched);
    TEST_PASS();
}

/* Main test runner */
int
main(int argc, char **argv)
{
    int ret;
    int passed = 0, failed = 0;
    
    /* Initialize EAL */
    ret = rte_eal_init(argc, argv);
    if (ret < 0)
        rte_exit(EXIT_FAILURE, "Error with EAL initialization\n");
    
    /* Create mbuf pool */
    pktmbuf_pool = rte_pktmbuf_pool_create("test_pool", 8192,
                                           250, 0,
                                           RTE_MBUF_DEFAULT_BUF_SIZE,
                                           rte_socket_id());
    if (pktmbuf_pool == NULL)
        rte_exit(EXIT_FAILURE, "Cannot create mbuf pool\n");
    
    printf("=== HFSC Scheduler Test Suite ===\n\n");
    
    /* Run tests */
    #define RUN_TEST(test) \
        do { \
            if (test() == 0) { \
                passed++; \
            } else { \
                failed++; \
            } \
        } while (0)
    
    RUN_TEST(test_init);
    RUN_TEST(test_root_creation);
    RUN_TEST(test_hierarchy_creation);
    RUN_TEST(test_service_curves);
    RUN_TEST(test_enqueue_activation);
    RUN_TEST(test_dequeue_deactivation);
    RUN_TEST(test_service_accounting);
    RUN_TEST(test_rt_selection);
    RUN_TEST(test_virtual_time);
    RUN_TEST(test_usc_enforcement);
    RUN_TEST(test_queue_overflow);
    RUN_TEST(test_statistics);
    
    printf("\n=== Test Results ===\n");
    printf("Passed: %d\n", passed);
    printf("Failed: %d\n", failed);
    printf("Total:  %d\n", passed + failed);
    
    if (failed == 0) {
        printf("\n✓ All tests passed!\n");
        return 0;
    } else {
        printf("\n✗ Some tests failed!\n");
        return 1;
    }
}
