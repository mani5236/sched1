/********************************************************************
 * HFSC Example Application - Network Accelerator Integration
 * 
 * This demonstrates how to use HFSC in a DPDK-based network device
 * with classification, queueing, and scheduling.
 ********************************************************************/

#include "hfsc_scheduler.h"
#include <rte_eal.h>
#include <rte_ethdev.h>
#include <rte_mbuf.h>
#include <rte_ip.h>
#include <rte_tcp.h>
#include <rte_udp.h>
#include <rte_ether.h>
#include <signal.h>

/* ==================== CONFIGURATION ==================== */

#define RX_RING_SIZE 1024
#define TX_RING_SIZE 1024
#define NUM_MBUFS 8191
#define MBUF_CACHE_SIZE 250
#define BURST_SIZE 32

/* Port configuration */
static uint16_t nb_ports = 0;
static volatile bool force_quit = false;

/* HFSC scheduler */
static hfsc_scheduler_t *sched = NULL;

/* Class pointers for easy access */
static hfsc_class_t *root_class = NULL;
static hfsc_class_t *site1_class = NULL;
static hfsc_class_t *site2_class = NULL;
static hfsc_class_t *udp1_class = NULL;
static hfsc_class_t *tcp1_class = NULL;
static hfsc_class_t *udp2_class = NULL;
static hfsc_class_t *tcp2_class = NULL;
static hfsc_class_t *default_class = NULL;

/* ==================== SIGNAL HANDLER ==================== */

static void
signal_handler(int signum)
{
    if (signum == SIGINT || signum == SIGTERM) {
        printf("\n\nSignal %d received, preparing to exit...\n", signum);
        force_quit = true;
    }
}

/* ==================== PORT CONFIGURATION ==================== */

static struct rte_eth_conf port_conf = {
    .rxmode = {
        .max_lro_pkt_size = RTE_ETHER_MAX_LEN,
    },
    .txmode = {
        .mq_mode = RTE_ETH_MQ_TX_NONE,
    },
};

static int
port_init(uint16_t port, struct rte_mempool *mbuf_pool)
{
    struct rte_eth_conf conf = port_conf;
    const uint16_t rx_rings = 1, tx_rings = 1;
    uint16_t nb_rxd = RX_RING_SIZE;
    uint16_t nb_txd = TX_RING_SIZE;
    int retval;
    struct rte_eth_dev_info dev_info;
    
    if (!rte_eth_dev_is_valid_port(port))
        return -1;
    
    retval = rte_eth_dev_info_get(port, &dev_info);
    if (retval != 0) {
        printf("Error getting device info for port %u: %s\n",
               port, strerror(-retval));
        return retval;
    }
    
    retval = rte_eth_dev_configure(port, rx_rings, tx_rings, &conf);
    if (retval != 0)
        return retval;
    
    retval = rte_eth_dev_adjust_nb_rx_tx_desc(port, &nb_rxd, &nb_txd);
    if (retval != 0)
        return retval;
    
    /* Allocate and set up RX queue */
    retval = rte_eth_rx_queue_setup(port, 0, nb_rxd,
                                     rte_eth_dev_socket_id(port),
                                     NULL, mbuf_pool);
    if (retval < 0)
        return retval;
    
    /* Allocate and set up TX queue */
    retval = rte_eth_tx_queue_setup(port, 0, nb_txd,
                                     rte_eth_dev_socket_id(port),
                                     NULL);
    if (retval < 0)
        return retval;
    
    /* Start the device */
    retval = rte_eth_dev_start(port);
    if (retval < 0)
        return retval;
    
    /* Enable promiscuous mode */
    retval = rte_eth_promiscuous_enable(port);
    if (retval != 0)
        return retval;
    
    return 0;
}

/* ==================== PACKET CLASSIFICATION ==================== */

/**
 * Classify packet to appropriate HFSC class
 * 
 * Example classification based on:
 * - IP addresses (192.168.2.20 -> site1, 192.168.2.30 -> site2)
 * - Ports (5001/5002 -> site1, 6001/6002 -> site2)
 * - Protocol (UDP vs TCP)
 */
static hfsc_class_t *
classify_packet(struct rte_mbuf *m)
{
    struct rte_ether_hdr *eth_hdr;
    struct rte_ipv4_hdr *ip_hdr;
    struct rte_tcp_hdr *tcp_hdr;
    struct rte_udp_hdr *udp_hdr;
    uint32_t src_ip, dst_ip;
    uint16_t dst_port = 0;
    uint8_t proto;
    
    eth_hdr = rte_pktmbuf_mtod(m, struct rte_ether_hdr *);
    
    /* Only handle IPv4 */
    if (eth_hdr->ether_type != rte_cpu_to_be_16(RTE_ETHER_TYPE_IPV4))
        return default_class;
    
    ip_hdr = (struct rte_ipv4_hdr *)(eth_hdr + 1);
    
    /* Get IP addresses */
    src_ip = rte_be_to_cpu_32(ip_hdr->src_addr);
    dst_ip = rte_be_to_cpu_32(ip_hdr->dst_addr);
    proto = ip_hdr->next_proto_id;
    
    /* Extract destination port */
    if (proto == IPPROTO_UDP) {
        udp_hdr = (struct rte_udp_hdr *)(ip_hdr + 1);
        dst_port = rte_be_to_cpu_16(udp_hdr->dst_port);
    } else if (proto == IPPROTO_TCP) {
        tcp_hdr = (struct rte_tcp_hdr *)(ip_hdr + 1);
        dst_port = rte_be_to_cpu_16(tcp_hdr->dst_port);
    }
    
    /* Classification logic:
     * UDP port 5001 -> udp1 (site1, real-time video)
     * TCP port 5002 -> tcp1 (site1, bulk transfer)
     * UDP port 6001 -> udp2 (site2, real-time video)
     * TCP port 6002 -> tcp2 (site2, bulk transfer)
     */
    
    if (proto == IPPROTO_UDP) {
        if (dst_port == 5001)
            return udp1_class;
        else if (dst_port == 6001)
            return udp2_class;
    } else if (proto == IPPROTO_TCP) {
        if (dst_port == 5002)
            return tcp1_class;
        else if (dst_port == 6002)
            return tcp2_class;
    }
    
    /* Default: classify by destination IP */
    if ((dst_ip & 0xFFFFFF00) == 0xC0A80200) { /* 192.168.2.x */
        if ((dst_ip & 0xFF) == 20)
            return tcp1_class; /* Default for site1 */
        else if ((dst_ip & 0xFF) == 30)
            return tcp2_class; /* Default for site2 */
    }
    
    return default_class;
}

/* ==================== HFSC HIERARCHY SETUP ==================== */

/**
 * Create HFSC class hierarchy
 * 
 * Hierarchy:
 *   root (100 Mbps)
 *     ├─ site1 (50 Mbps guaranteed, 60 Mbps max)
 *     │   ├─ udp1 (10 Mbps, 10ms delay, 16 Mbps max) [real-time video]
 *     │   └─ tcp1 (40 Mbps, 48 Mbps max) [bulk data]
 *     ├─ site2 (50 Mbps guaranteed, 60 Mbps max)
 *     │   ├─ udp2 (10 Mbps, 10ms delay, 16 Mbps max) [real-time video]
 *     │   └─ tcp2 (40 Mbps, 48 Mbps max) [bulk data]
 *     └─ default (best effort, uses remaining capacity)
 */
static int
setup_hfsc_hierarchy(void)
{
    hfsc_service_curve_t sc;
    
    /* Create root class: 100 Mbps */
    sc = (hfsc_service_curve_t){
        .m1 = 12500000,  /* 100 Mbps in bytes/sec */
        .d = 0,
        .m2 = 12500000
    };
    root_class = hfsc_create_root(sched, &sc, &sc, &sc);
    if (!root_class) {
        printf("Failed to create root class\n");
        return -1;
    }
    
    /* Site 1: 50 Mbps guaranteed, 60 Mbps max */
    sc = (hfsc_service_curve_t){
        .m1 = 6250000,   /* 50 Mbps */
        .d = 0,
        .m2 = 6250000
    };
    site1_class = hfsc_create_class(sched, root_class, 1, false,
                                    &sc, &sc,
                                    &(hfsc_service_curve_t){
                                        .m1 = 7500000,  /* 60 Mbps max */
                                        .d = 0,
                                        .m2 = 7500000
                                    });
    if (!site1_class) {
        printf("Failed to create site1 class\n");
        return -1;
    }
    
    /* UDP1: Real-time video - 10 Mbps, 10ms delay guarantee, 16 Mbps max */
    udp1_class = hfsc_create_class(sched, site1_class, 11, true,
                                   &(hfsc_service_curve_t){
                                       .m1 = 5000000,   /* 40 Mbps initial for low delay */
                                       .d = 10000,      /* 10ms delay */
                                       .m2 = 1250000    /* 10 Mbps sustained */
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 1250000,   /* 10 Mbps fair share */
                                       .d = 0,
                                       .m2 = 1250000
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 2000000,   /* 16 Mbps max */
                                       .d = 0,
                                       .m2 = 2000000
                                   });
    if (!udp1_class) {
        printf("Failed to create udp1 class\n");
        return -1;
    }
    
    /* TCP1: Bulk transfer - 40 Mbps, 48 Mbps max */
    tcp1_class = hfsc_create_class(sched, site1_class, 12, true,
                                   &(hfsc_service_curve_t){
                                       .m1 = 5000000,   /* 40 Mbps */
                                       .d = 0,
                                       .m2 = 5000000
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 5000000,
                                       .d = 0,
                                       .m2 = 5000000
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 6000000,   /* 48 Mbps max */
                                       .d = 0,
                                       .m2 = 6000000
                                   });
    if (!tcp1_class) {
        printf("Failed to create tcp1 class\n");
        return -1;
    }
    
    /* Site 2: Same as Site 1 */
    sc = (hfsc_service_curve_t){
        .m1 = 6250000,
        .d = 0,
        .m2 = 6250000
    };
    site2_class = hfsc_create_class(sched, root_class, 2, false,
                                    &sc, &sc,
                                    &(hfsc_service_curve_t){
                                        .m1 = 7500000,
                                        .d = 0,
                                        .m2 = 7500000
                                    });
    if (!site2_class) {
        printf("Failed to create site2 class\n");
        return -1;
    }
    
    /* UDP2: Real-time video */
    udp2_class = hfsc_create_class(sched, site2_class, 21, true,
                                   &(hfsc_service_curve_t){
                                       .m1 = 5000000,
                                       .d = 10000,
                                       .m2 = 1250000
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 1250000,
                                       .d = 0,
                                       .m2 = 1250000
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 2000000,
                                       .d = 0,
                                       .m2 = 2000000
                                   });
    if (!udp2_class) {
        printf("Failed to create udp2 class\n");
        return -1;
    }
    
    /* TCP2: Bulk transfer */
    tcp2_class = hfsc_create_class(sched, site2_class, 22, true,
                                   &(hfsc_service_curve_t){
                                       .m1 = 5000000,
                                       .d = 0,
                                       .m2 = 5000000
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 5000000,
                                       .d = 0,
                                       .m2 = 5000000
                                   },
                                   &(hfsc_service_curve_t){
                                       .m1 = 6000000,
                                       .d = 0,
                                       .m2 = 6000000
                                   });
    if (!tcp2_class) {
        printf("Failed to create tcp2 class\n");
        return -1;
    }
    
    /* Default class: Best effort */
    default_class = hfsc_create_class(sched, root_class, 99, true,
                                      NULL,
                                      &(hfsc_service_curve_t){
                                          .m1 = 100000,  /* 800 Kbps minimum */
                                          .d = 0,
                                          .m2 = 100000
                                      },
                                      NULL);
    if (!default_class) {
        printf("Failed to create default class\n");
        return -1;
    }
    
    printf("HFSC hierarchy created successfully:\n");
    printf("  root (100 Mbps)\n");
    printf("    ├─ site1 (50 Mbps, max 60 Mbps)\n");
    printf("    │   ├─ udp1 (10 Mbps RT, max 16 Mbps)\n");
    printf("    │   └─ tcp1 (40 Mbps, max 48 Mbps)\n");
    printf("    ├─ site2 (50 Mbps, max 60 Mbps)\n");
    printf("    │   ├─ udp2 (10 Mbps RT, max 16 Mbps)\n");
    printf("    │   └─ tcp2 (40 Mbps, max 48 Mbps)\n");
    printf("    └─ default (800 Kbps minimum)\n\n");
    
    return 0;
}

/* ==================== STATISTICS ==================== */

static void
print_stats(void)
{
    uint64_t packets, bytes, drops;
    
    printf("\n=== HFSC Statistics ===\n");
    
    printf("UDP1 (Real-time): ");
    hfsc_get_class_stats(udp1_class, &packets, &bytes, &drops);
    printf("TX: %lu pkts (%lu MB), Drops: %lu\n",
           packets, bytes / 1000000, drops);
    
    printf("TCP1 (Bulk):      ");
    hfsc_get_class_stats(tcp1_class, &packets, &bytes, &drops);
    printf("TX: %lu pkts (%lu MB), Drops: %lu\n",
           packets, bytes / 1000000, drops);
    
    printf("UDP2 (Real-time): ");
    hfsc_get_class_stats(udp2_class, &packets, &bytes, &drops);
    printf("TX: %lu pkts (%lu MB), Drops: %lu\n",
           packets, bytes / 1000000, drops);
    
    printf("TCP2 (Bulk):      ");
    hfsc_get_class_stats(tcp2_class, &packets, &bytes, &drops);
    printf("TX: %lu pkts (%lu MB), Drops: %lu\n",
           packets, bytes / 1000000, drops);
    
    printf("Default:          ");
    hfsc_get_class_stats(default_class, &packets, &bytes, &drops);
    printf("TX: %lu pkts (%lu MB), Drops: %lu\n",
           packets, bytes / 1000000, drops);
}

/* ==================== MAIN LOOP ==================== */

static void
lcore_main(uint16_t rx_port, uint16_t tx_port)
{
    struct rte_mbuf *rx_bufs[BURST_SIZE];
    struct rte_mbuf *tx_buf;
    uint16_t nb_rx, nb_tx;
    hfsc_class_t *cl;
    uint64_t next_stats = 0;
    uint64_t tsc_hz = rte_get_tsc_hz();
    
    printf("Core %u forwarding packets from port %u to port %u\n",
           rte_lcore_id(), rx_port, tx_port);
    printf("Press Ctrl+C to exit\n\n");
    
    while (!force_quit) {
        /* Receive burst */
        nb_rx = rte_eth_rx_burst(rx_port, 0, rx_bufs, BURST_SIZE);
        
        /* Classify and enqueue */
        for (uint16_t i = 0; i < nb_rx; i++) {
            cl = classify_packet(rx_bufs[i]);
            if (hfsc_enqueue(sched, cl, rx_bufs[i]) < 0) {
                rte_pktmbuf_free(rx_bufs[i]);
            }
        }
        
        /* Dequeue and transmit */
        nb_tx = 0;
        while (nb_tx < BURST_SIZE && hfsc_has_packets(sched)) {
            tx_buf = hfsc_dequeue(sched);
            if (tx_buf == NULL)
                break;
            
            /* Try to send */
            if (rte_eth_tx_burst(tx_port, 0, &tx_buf, 1) == 0) {
                /* TX queue full, re-enqueue or drop */
                rte_pktmbuf_free(tx_buf);
            }
            nb_tx++;
        }
        
        /* Print stats every 5 seconds */
        uint64_t now = rte_get_tsc_cycles();
        if (now > next_stats) {
            print_stats();
            next_stats = now + (tsc_hz * 5);
        }
    }
    
    print_stats();
    printf("\nShutting down...\n");
}

/* ==================== MAIN ==================== */

int
main(int argc, char *argv[])
{
    struct rte_mempool *mbuf_pool;
    unsigned nb_ports_available;
    uint16_t portid;
    int ret;
    
    /* Initialize EAL */
    ret = rte_eal_init(argc, argv);
    if (ret < 0)
        rte_exit(EXIT_FAILURE, "Error with EAL initialization\n");
    
    argc -= ret;
    argv += ret;
    
    /* Check ports */
    nb_ports = rte_eth_dev_count_avail();
    if (nb_ports < 2)
        rte_exit(EXIT_FAILURE, "Error: need at least 2 ports\n");
    
    /* Create mbuf pool */
    mbuf_pool = rte_pktmbuf_pool_create("MBUF_POOL", NUM_MBUFS * nb_ports,
                                         MBUF_CACHE_SIZE, 0,
                                         RTE_MBUF_DEFAULT_BUF_SIZE,
                                         rte_socket_id());
    if (mbuf_pool == NULL)
        rte_exit(EXIT_FAILURE, "Cannot create mbuf pool\n");
    
    /* Initialize HFSC scheduler */
    if (hfsc_init(&sched) < 0)
        rte_exit(EXIT_FAILURE, "Failed to initialize HFSC\n");
    
    /* Setup HFSC hierarchy */
    if (setup_hfsc_hierarchy() < 0)
        rte_exit(EXIT_FAILURE, "Failed to setup HFSC hierarchy\n");
    
    /* Initialize ports */
    nb_ports_available = 0;
    RTE_ETH_FOREACH_DEV(portid) {
        if (port_init(portid, mbuf_pool) != 0)
            rte_exit(EXIT_FAILURE, "Cannot init port %u\n", portid);
        nb_ports_available++;
    }
    
    if (nb_ports_available < 2)
        rte_exit(EXIT_FAILURE, "Not enough available ports\n");
    
    /* Setup signal handlers */
    signal(SIGINT, signal_handler);
    signal(SIGTERM, signal_handler);
    
    /* Launch main loop on main lcore */
    lcore_main(0, 1);
    
    /* Cleanup */
    printf("\nCleaning up...\n");
    
    RTE_ETH_FOREACH_DEV(portid) {
        printf("Closing port %u...", portid);
        ret = rte_eth_dev_stop(portid);
        if (ret != 0)
            printf("rte_eth_dev_stop: err=%d, port=%u\n", ret, portid);
        rte_eth_dev_close(portid);
        printf(" Done\n");
    }
    
    hfsc_cleanup(sched);
    
    /* Clean up EAL */
    rte_eal_cleanup();
    
    printf("Bye...\n");
    return 0;
}
